package com.nio.logfilter;

public class LogColor
{
                                        //aarrggbb
    public static int   COLOR_GUIDE     = 0x00000000;
    public static int   COLOR_BOOKMARK  = 0x00DDDDDD;
    public static int   COLOR_BOOKMARK2 = 0x00DDDDFF;
    public static int   COLOR_DEBUG     = 0x000000AA;
    public static int   COLOR_ERROR     = 0x00FF0000;
    public static int   COLOR_FATAL     = 0x00FF0000;
    public static int   COLOR_INFO      = 0x00009A00;
    public static int   COLOR_WARN      = 0x00FF9A00;
    public static int   COLOR_0         = 0x00000000;
    public static int   COLOR_1         = 0x00000000;
    public static int   COLOR_2         = 0x00000000;
    public static int   COLOR_3         = COLOR_ERROR;
    public static int   COLOR_4         = COLOR_WARN;
    public static int   COLOR_5         = 0x00000000;
    public static int   COLOR_6         = COLOR_INFO;
    public static int   COLOR_7         = COLOR_DEBUG;
    public static int   COLOR_8         = COLOR_ERROR;
    public static String[] COLOR_HIGHLIGHT;
}
