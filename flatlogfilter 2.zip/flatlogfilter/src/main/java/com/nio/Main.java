package com.nio;

import com.formdev.flatlaf.fonts.jetbrains_mono.FlatJetBrainsMonoFont;
import com.formdev.flatlaf.themes.FlatMacLightLaf;
import com.nio.logfilter.LogFilterMain;

import javax.swing.*;
import javax.swing.text.StyledEditorKit;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        setupDefaultUI();

        FlatMacLightLaf.setup();
        FlatJetBrainsMonoFont.install();

        LogFilterMain.launch(new String[]{});
    }

    private static void setupDefaultUI() {
        UIManager.put("defaultFont", new Font(FlatJetBrainsMonoFont.FAMILY, Font.PLAIN, 12));
    }
}