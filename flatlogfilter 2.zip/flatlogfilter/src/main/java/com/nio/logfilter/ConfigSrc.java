package com.nio.logfilter;

public class ConfigSrc {
    public static final String CMD = "CMD_COUNT=5\n" +
            "CMD_0=logcat -v threadtime\n" +
            "CMD_1=logcat -v time\n" +
            "CMD_2=logcat -b radio -v time\n" +
            "CMD_3=logcat -b events -v time\n" +
            "CMD_4=shell cat /proc/kmsg";
}
