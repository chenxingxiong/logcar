#!/bin/sh
shell_floder=$(dirname $(readlink -f "$0"))
cd $shell_floder
pwd
java -jar FlatLogFilter.jar
