package com.nio.logfilter;

import javax.swing.JPanel;

public class DevicesPanel extends JPanel
{
    private static final long serialVersionUID = 1L;
    
}
